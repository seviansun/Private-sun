﻿for(var i = 0; i < 349; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
u70.tabIndex = 0;

u70.style.cursor = 'pointer';
$axure.eventManager.click('u70', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('2_1_2日记本编辑页（编辑者查看）.html');

}
});
gv_vAlignTable['u71'] = 'top';gv_vAlignTable['u73'] = 'center';gv_vAlignTable['u250'] = 'center';gv_vAlignTable['u252'] = 'center';gv_vAlignTable['u254'] = 'center';gv_vAlignTable['u256'] = 'center';gv_vAlignTable['u258'] = 'center';gv_vAlignTable['u80'] = 'center';u81.tabIndex = 0;

u81.style.cursor = 'pointer';
$axure.eventManager.click('u81', function(e) {

if (true) {

	SetPanelVisibility('u82','toggle','none',500);

}
});
gv_vAlignTable['u81'] = 'top';gv_vAlignTable['u261'] = 'top';gv_vAlignTable['u262'] = 'top';gv_vAlignTable['u183'] = 'center';document.getElementById('u184_img').tabIndex = 0;

u184.style.cursor = 'pointer';
$axure.eventManager.click('u184', function(e) {

if (true) {

	SetPanelState('u0', 'pd2u0','none','',500,'none','',500);

}
});
gv_vAlignTable['u185'] = 'center';gv_vAlignTable['u187'] = 'center';gv_vAlignTable['u189'] = 'center';gv_vAlignTable['u24'] = 'top';gv_vAlignTable['u194'] = 'center';document.getElementById('u195_img').tabIndex = 0;

u195.style.cursor = 'pointer';
$axure.eventManager.click('u195', function(e) {

if (true) {

	SetPanelState('u0', 'pd0u0','none','',500,'none','',500);

}
});
gv_vAlignTable['u196'] = 'center';gv_vAlignTable['u140'] = 'center';gv_vAlignTable['u65'] = 'center';gv_vAlignTable['u67'] = 'center';gv_vAlignTable['u69'] = 'center';document.getElementById('u74_img').tabIndex = 0;

u74.style.cursor = 'pointer';
$axure.eventManager.click('u74', function(e) {

if (true) {

	SetPanelState('u0', 'pd1u0','none','',500,'none','',500);

}
});
gv_vAlignTable['u75'] = 'center';gv_vAlignTable['u77'] = 'center';gv_vAlignTable['u78'] = 'top';gv_vAlignTable['u300'] = 'top';gv_vAlignTable['u302'] = 'center';document.getElementById('u303_img').tabIndex = 0;

u303.style.cursor = 'pointer';
$axure.eventManager.click('u303', function(e) {

if (true) {

	SetPanelState('u0', 'pd1u0','none','',500,'none','',500);

}
});
gv_vAlignTable['u304'] = 'center';u305.tabIndex = 0;

u305.style.cursor = 'pointer';
$axure.eventManager.click('u305', function(e) {

if (true) {

	SetPanelVisibility('u312','toggle','none',500);

}
});
gv_vAlignTable['u305'] = 'top';gv_vAlignTable['u307'] = 'center';gv_vAlignTable['u309'] = 'center';gv_vAlignTable['u138'] = 'center';gv_vAlignTable['u84'] = 'center';gv_vAlignTable['u86'] = 'center';gv_vAlignTable['u87'] = 'top';gv_vAlignTable['u89'] = 'center';u190.tabIndex = 0;

u190.style.cursor = 'pointer';
$axure.eventManager.click('u190', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('2_1_2日记本编辑页（编辑者查看）.html');

}
});
gv_vAlignTable['u191'] = 'top';gv_vAlignTable['u192'] = 'top';u310.tabIndex = 0;

u310.style.cursor = 'pointer';
$axure.eventManager.click('u310', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('2_1_2日记本编辑页（编辑者查看）.html');

}
});
gv_vAlignTable['u311'] = 'top';gv_vAlignTable['u314'] = 'center';gv_vAlignTable['u316'] = 'center';gv_vAlignTable['u317'] = 'top';gv_vAlignTable['u319'] = 'center';gv_vAlignTable['u92'] = 'top';gv_vAlignTable['u94'] = 'center';gv_vAlignTable['u97'] = 'center';gv_vAlignTable['u99'] = 'center';gv_vAlignTable['u322'] = 'top';gv_vAlignTable['u324'] = 'center';gv_vAlignTable['u327'] = 'center';gv_vAlignTable['u329'] = 'center';document.getElementById('u1_img').tabIndex = 0;

u1.style.cursor = 'pointer';
$axure.eventManager.click('u1', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('2_2_1日记本详情页（评论者查看）.html');

}
});
gv_vAlignTable['u2'] = 'center';gv_vAlignTable['u4'] = 'center';gv_vAlignTable['u6'] = 'center';document.getElementById('u7_img').tabIndex = 0;

u7.style.cursor = 'pointer';
$axure.eventManager.click('u7', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('2_2_1日记本详情页（评论者查看）.html');

}
});
gv_vAlignTable['u8'] = 'center';u330.tabIndex = 0;

u330.style.cursor = 'pointer';
$axure.eventManager.click('u330', function(e) {

if (true) {

	SetPanelVisibility('u312','hidden','none',500);

}
});
gv_vAlignTable['u330'] = 'top';gv_vAlignTable['u332'] = 'top';gv_vAlignTable['u334'] = 'top';gv_vAlignTable['u336'] = 'center';u100.tabIndex = 0;

u100.style.cursor = 'pointer';
$axure.eventManager.click('u100', function(e) {

if (true) {

	SetPanelVisibility('u82','hidden','none',500);

}
});
gv_vAlignTable['u100'] = 'top';u101.tabIndex = 0;

u101.style.cursor = 'pointer';
$axure.eventManager.click('u101', function(e) {

if (true) {

	SetPanelVisibility('u102','toggle','none',500);

}
});
gv_vAlignTable['u101'] = 'top';gv_vAlignTable['u104'] = 'center';gv_vAlignTable['u106'] = 'center';gv_vAlignTable['u107'] = 'top';gv_vAlignTable['u109'] = 'center';gv_vAlignTable['u10'] = 'center';gv_vAlignTable['u12'] = 'center';gv_vAlignTable['u14'] = 'center';gv_vAlignTable['u16'] = 'center';gv_vAlignTable['u18'] = 'center';gv_vAlignTable['u344'] = 'top';gv_vAlignTable['u345'] = 'top';gv_vAlignTable['u346'] = 'top';gv_vAlignTable['u347'] = 'top';u348.tabIndex = 0;

u348.style.cursor = 'pointer';
$axure.eventManager.click('u348', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('2_2日记列表页（评论者查看）.html');

}
});
gv_vAlignTable['u348'] = 'top';gv_vAlignTable['u343'] = 'top';gv_vAlignTable['u112'] = 'top';gv_vAlignTable['u114'] = 'center';gv_vAlignTable['u117'] = 'center';gv_vAlignTable['u119'] = 'center';gv_vAlignTable['u20'] = 'center';gv_vAlignTable['u23'] = 'top';gv_vAlignTable['u200'] = 'center';u201.tabIndex = 0;

u201.style.cursor = 'pointer';
$axure.eventManager.click('u201', function(e) {

if (true) {

	SetPanelVisibility('u202','toggle','none',500);

}
});
gv_vAlignTable['u201'] = 'top';gv_vAlignTable['u204'] = 'center';gv_vAlignTable['u206'] = 'center';gv_vAlignTable['u207'] = 'top';gv_vAlignTable['u209'] = 'center';u120.tabIndex = 0;

u120.style.cursor = 'pointer';
$axure.eventManager.click('u120', function(e) {

if (true) {

	SetPanelVisibility('u102','hidden','none',500);

}
});
gv_vAlignTable['u120'] = 'top';document.getElementById('u121_img').tabIndex = 0;

u121.style.cursor = 'pointer';
$axure.eventManager.click('u121', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('2_2_1日记本详情页（评论者查看）.html');

}
});
gv_vAlignTable['u122'] = 'center';gv_vAlignTable['u124'] = 'center';gv_vAlignTable['u126'] = 'center';document.getElementById('u127_img').tabIndex = 0;

u127.style.cursor = 'pointer';
$axure.eventManager.click('u127', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('2_2_1日记本详情页（评论者查看）.html');

}
});
gv_vAlignTable['u128'] = 'center';gv_vAlignTable['u212'] = 'top';gv_vAlignTable['u214'] = 'center';gv_vAlignTable['u217'] = 'center';gv_vAlignTable['u219'] = 'center';gv_vAlignTable['u130'] = 'center';gv_vAlignTable['u132'] = 'center';gv_vAlignTable['u134'] = 'center';gv_vAlignTable['u136'] = 'center';gv_vAlignTable['u198'] = 'center';u220.tabIndex = 0;

u220.style.cursor = 'pointer';
$axure.eventManager.click('u220', function(e) {

if (true) {

	SetPanelVisibility('u202','hidden','none',500);

}
});
gv_vAlignTable['u220'] = 'top';u221.tabIndex = 0;

u221.style.cursor = 'pointer';
$axure.eventManager.click('u221', function(e) {

if (true) {

	SetPanelVisibility('u222','toggle','none',500);

}
});
gv_vAlignTable['u221'] = 'top';gv_vAlignTable['u224'] = 'center';gv_vAlignTable['u226'] = 'center';gv_vAlignTable['u227'] = 'top';gv_vAlignTable['u229'] = 'center';gv_vAlignTable['u143'] = 'top';gv_vAlignTable['u144'] = 'top';gv_vAlignTable['u232'] = 'top';gv_vAlignTable['u234'] = 'center';gv_vAlignTable['u237'] = 'center';gv_vAlignTable['u239'] = 'center';gv_vAlignTable['u340'] = 'top';gv_vAlignTable['u341'] = 'top';gv_vAlignTable['u342'] = 'top';gv_vAlignTable['u63'] = 'center';u240.tabIndex = 0;

u240.style.cursor = 'pointer';
$axure.eventManager.click('u240', function(e) {

if (true) {

	SetPanelVisibility('u222','hidden','none',500);

}
});
gv_vAlignTable['u240'] = 'top';gv_vAlignTable['u242'] = 'center';gv_vAlignTable['u244'] = 'center';document.getElementById('u245_img').tabIndex = 0;

u245.style.cursor = 'pointer';
$axure.eventManager.click('u245', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('2_2_1日记本详情页（评论者查看）.html');

}
});
gv_vAlignTable['u246'] = 'center';gv_vAlignTable['u248'] = 'center';