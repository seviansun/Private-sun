﻿for(var i = 0; i < 163; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
document.getElementById('u156_img').tabIndex = 0;

u156.style.cursor = 'pointer';
$axure.eventManager.click('u156', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('2_1_1日记本详情页（编辑者查看）.html');

}
});
gv_vAlignTable['u157'] = 'center';gv_vAlignTable['u158'] = 'top';gv_vAlignTable['u159'] = 'top';gv_vAlignTable['u80'] = 'center';gv_vAlignTable['u82'] = 'center';gv_vAlignTable['u84'] = 'center';gv_vAlignTable['u86'] = 'center';
$axure.eventManager.mouseover('u87', function(e) {
if (!IsTrueMouseOver('u87',e)) return;
if (true) {

	SetPanelState('u0', 'pd1u0','none','',500,'none','',500);

}
});
gv_vAlignTable['u88'] = 'center';gv_vAlignTable['u161'] = 'top';u162.tabIndex = 0;

u162.style.cursor = 'pointer';
$axure.eventManager.click('u162', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('2_2日记列表页（评论者查看）.html');

}
});
gv_vAlignTable['u162'] = 'top';gv_vAlignTable['u90'] = 'center';gv_vAlignTable['u92'] = 'center';gv_vAlignTable['u95'] = 'top';gv_vAlignTable['u96'] = 'top';
$axure.eventManager.mouseover('u17', function(e) {
if (!IsTrueMouseOver('u17',e)) return;
if (true) {

	SetPanelState('u0', 'pd0u0','none','',500,'none','',500);

}
});
gv_vAlignTable['u18'] = 'center';gv_vAlignTable['u21'] = 'top';gv_vAlignTable['u10'] = 'center';gv_vAlignTable['u12'] = 'center';gv_vAlignTable['u14'] = 'center';gv_vAlignTable['u16'] = 'center';gv_vAlignTable['u41'] = 'top';gv_vAlignTable['u44'] = 'center';gv_vAlignTable['u46'] = 'center';gv_vAlignTable['u48'] = 'center';gv_vAlignTable['u2'] = 'center';gv_vAlignTable['u4'] = 'center';document.getElementById('u5_img').tabIndex = 0;

u5.style.cursor = 'pointer';
$axure.eventManager.click('u5', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('2_2_1日记本详情页（评论者查看）.html');

}
});
gv_vAlignTable['u6'] = 'center';gv_vAlignTable['u8'] = 'center';gv_vAlignTable['u50'] = 'center';gv_vAlignTable['u53'] = 'top';gv_vAlignTable['u133'] = 'top';gv_vAlignTable['u136'] = 'center';gv_vAlignTable['u138'] = 'center';gv_vAlignTable['u139'] = 'top';gv_vAlignTable['u153'] = 'top';gv_vAlignTable['u154'] = 'top';gv_vAlignTable['u155'] = 'top';gv_vAlignTable['u141'] = 'center';gv_vAlignTable['u143'] = 'center';gv_vAlignTable['u144'] = 'top';u148.tabIndex = 0;

u148.style.cursor = 'pointer';
$axure.eventManager.click('u148', function(e) {

if (true) {

	SetPanelVisibility('u146','','none',500);

}
});

$axure.eventManager.mouseout('u148', function(e) {
if (!IsTrueMouseOut('u148',e)) return;
if (true) {

	SetPanelVisibility('u146','hidden','none',500);

}
});
gv_vAlignTable['u160'] = 'top';gv_vAlignTable['u71'] = 'top';u73.tabIndex = 0;

u73.style.cursor = 'pointer';
$axure.eventManager.click('u73', function(e) {

if (true) {

	SetPanelVisibility('u51','','none',500);

}
});

$axure.eventManager.mouseout('u73', function(e) {
if (!IsTrueMouseOut('u73',e)) return;
if (true) {

	SetPanelVisibility('u51','hidden','none',500);

}
});
gv_vAlignTable['u74'] = 'top';gv_vAlignTable['u76'] = 'center';gv_vAlignTable['u78'] = 'center';document.getElementById('u79_img').tabIndex = 0;

u79.style.cursor = 'pointer';
$axure.eventManager.click('u79', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('2_2_1日记本详情页（评论者查看）.html');

}
});
gv_vAlignTable['u150'] = 'center';