﻿var sitemap = 

(function() {
    var _ = function() { var r={},a=arguments; for(var i=0; i<a.length; i+=2) r[a[i]]=a[i+1]; return r; }
    var _creator = function() { return _(b,[_(c,d,e,f,g,h),_(c,i,e,f,g,j,k,[_(c,l,e,f,g,m),_(c,n,e,f,g,o,k,[_(c,p,e,f,g,q),_(c,r,e,f,g,s)]),_(c,t,e,f,g,u,k,[_(c,v,e,f,g,w),_(c,x,e,f,g,y)])])]);}; 
var b="rootNodes",c="pageName",d="更新记录",e="type",f="Wireframe",g="url",h="更新记录.html",i="记录分享PRD",j="记录分享PRD.html",k="children",l="1.需求",m="1_需求.html",n="2.1日记列表页（编辑者查看）",o="2_1日记列表页（编辑者查看）.html",p="2.1.1日记本详情页（编辑者查看）",q="2_1_1日记本详情页（编辑者查看）.html",r="2.1.2日记本编辑页（编辑者查看）",s="2_1_2日记本编辑页（编辑者查看）.html",t="2.2日记列表页（评论者查看）",u="2_2日记列表页（评论者查看）.html",v="2.2.1日记本详情页（评论者查看）",w="2_2_1日记本详情页（评论者查看）.html",x="2.2.2日记本编辑页（评论者查看）",y="2_2_2日记本编辑页（评论者查看）.html";
return _creator();
})();
